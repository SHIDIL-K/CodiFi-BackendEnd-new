from django.contrib import admin
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    # Auth & Profile
    RegisterView, StudentRegisterView, InstructorRegisterView,
    ProfileView, CustomTokenObtainPairView,

    # Course-related
    CourseListView, CourseDetailView, CourseSearchView,
    CourseLessonsView, 

    # Enrollment & Payment
    EnrollmentCreateView, PaymentCreateView,

    # Feedback
    FeedbackCreateView,

    # Instructor-related
    InstructorListView, InstructorCourseListView, LessonCreateView, InstructorEnrollmentListView,

    # Tasks & Quizzes
    DailyTaskListView, TaskSubmissionCreateView, QuizSubmitView,

    # Chatbot
    
)

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Django Admin (superuser handles all admin tasks here)
    path('admin/', admin.site.urls),

    # Authentication & Registration
    path('api/register/', RegisterView.as_view(), name='register'),
    path('api/register/student/', StudentRegisterView.as_view(), name='register-student'),
    path('api/register/instructor/', InstructorRegisterView.as_view(), name='register-instructor'),
    path('api/profile/', ProfileView.as_view(), name='profile'),

    # JWT Tokens
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair_custom'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Courses (public)
    path('api/courses/', CourseListView.as_view(), name='course-list'),
    path('api/courses/search/', CourseSearchView.as_view(), name='course-search'),
    path('api/courses/<int:pk>/detail/', CourseDetailView.as_view(), name='course-detail'),
    path('api/courses/<int:pk>/lessons/', CourseLessonsView.as_view(), name='course-lessons'),
    # path('api/courses/<int:pk>/quizzes/', CourseQuizListView.as_view(), name='course-quizzes'),

    # Enrollment & Payments
    path('api/enroll/', EnrollmentCreateView.as_view(), name='enroll'),
    path('api/payments/', PaymentCreateView.as_view(), name='payment-create'),

    # Feedback
    path('api/feedback/', FeedbackCreateView.as_view(), name='feedback-create'),

    # Instructor related
    path('api/instructors/', InstructorListView.as_view(), name='instructor-list'),
    path('api/instructor/courses/', InstructorCourseListView.as_view(), name='instructor-courses'),
    path('api/instructor/lessons/create/', LessonCreateView.as_view(), name='instructor-lesson-create'),
    # path('api/instructor/tasks/<int:pk>/review/', InstructorTaskReviewView.as_view(), name='instructor-task-review'),
    path('api/instructor/enrollments/', InstructorEnrollmentListView.as_view(), name='instructor-enrollments'),

    # Daily Tasks
    path('api/tasks/', DailyTaskListView.as_view(), name='task-list'),
    path('api/tasks/submit/', TaskSubmissionCreateView.as_view(), name='task-submit'),

    # Quizzes
    path('api/quizzes/submit/', QuizSubmitView.as_view(), name='quiz-submit'),

    # Chatbot
    # path('api/chat/', ChatMessageCreateView.as_view(), name='chat-create'),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
