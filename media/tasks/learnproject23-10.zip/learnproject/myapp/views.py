# --- (imports stay exactly the same) ---

# Keep all imports as they are
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.core.mail import send_mail
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.db.models import Sum
from django.db import transaction
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import filters
from rest_framework.decorators import api_view
from django.db.models import Count
from rest_framework import status

from .models import (
    User, Course, Enrollment, DailyTask, TaskSubmission, Offer, Feedback, Payment, Profile,
    Certificate, Module, Lesson, Quiz, QuizQuestion, QuizSubmission, LiveSession, ChatMessage
)
from .serializers import (
    RegisterSerializer, UserSerializer, CourseSerializer, EnrollmentSerializer,
    DailyTaskSerializer, TaskSubmissionSerializer, OfferSerializer, FeedbackSerializer,
    PaymentSerializer, CertificateSerializer, ModuleSerializer, LessonSerializer,
    QuizSerializer, QuizQuestionSerializer, QuizSubmissionSerializer, LiveSessionSerializer,
    ChatMessageSerializer, ProfileSerializer
)
from .permissions import IsInstructor, IsAdmin
from rest_framework.parsers import MultiPartParser, FormParser


# =======================================
# 1) JWT Login, Registration, Profile
# =======================================

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        if self.user.role == 'instructor' and not self.user.is_approved:
            raise AuthenticationFailed("Your instructor account is pending admin approval.")
        return data


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

    def perform_create(self, serializer):
        user = serializer.save()
        if user.role == 'instructor':
            send_mail(
                subject="Instructor Approval Pending",
                message=f"New instructor '{user.username}' has registered and is awaiting approval.",
                from_email="noreply@codifi.com",
                recipient_list=["admin@codifi.com"],
                fail_silently=True,
            )


class StudentRegisterView(RegisterView):
    def perform_create(self, serializer):
        serializer.save(role='student')


class InstructorRegisterView(RegisterView):
    def perform_create(self, serializer):
        serializer.save(role='instructor')


class ProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request):
        profile, _ = Profile.objects.get_or_create(user=request.user)
        serializer = ProfileSerializer(profile, context={"request": request})
        return Response(serializer.data)

    def put(self, request):
        profile, _ = Profile.objects.get_or_create(user=request.user)
        user = request.user

        profile.bio = request.data.get("bio", profile.bio)
        profile.phone = request.data.get("phone", profile.phone)
        profile.qualification = request.data.get("qualification", profile.qualification)
        profile.save()

        if "profile_picture" in request.FILES:
            user.profile_picture = request.FILES["profile_picture"]
        user.save()

        serializer = ProfileSerializer(profile, context={"request": request})
        return Response(serializer.data)


# =======================================
# 2) Courses (public + instructor)
# =======================================

class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.AllowAny]


# ❌ Removed AdminCourseCreateView & CourseRetrieveUpdateDeleteView
# Django superuser will manage Course creation/update via admin panel.


# =======================================
# 3) Enrollment + Payments
# =======================================

class EnrollmentCreateView(generics.CreateAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        student = self.request.user
        course = serializer.validated_data['course']
        serializer.save(student=student)


class PaymentCreateView(generics.CreateAPIView):
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]

    @transaction.atomic
    def perform_create(self, serializer):
        student = self.request.user
        course = serializer.validated_data['course']
        amount = serializer.validated_data['amount']

        # Apply offer if exists
        active_offer = Offer.objects.filter(is_active=True).order_by('-created_at').first()
        if active_offer and active_offer.discount_percent > 0:
            discount = (active_offer.discount_percent / 100) * float(amount)
            amount = float(amount) - discount

        payment = serializer.save(student=student, amount=amount)
        if payment.status == 'success':
            Enrollment.objects.get_or_create(student=student, course=course)


# =======================================
# 4) Daily Tasks, Quizzes, Lessons, Feedback
# =======================================

class DailyTaskListView(generics.ListAPIView):
    queryset = DailyTask.objects.all()
    serializer_class = DailyTaskSerializer
    permission_classes = [permissions.IsAuthenticated]


class TaskSubmissionCreateView(generics.CreateAPIView):
    serializer_class = TaskSubmissionSerializer
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def perform_create(self, serializer):
        student = self.request.user
        serializer.save(student=student)


class QuizSubmitView(generics.CreateAPIView):
    serializer_class = QuizSubmissionSerializer
    permission_classes = [permissions.IsAuthenticated]


class LessonCreateView(generics.CreateAPIView):
    serializer_class = LessonSerializer
    permission_classes = [IsInstructor]
    parser_classes = [MultiPartParser, FormParser]

    def perform_create(self, serializer):
        course_id = self.request.data.get("course")
        course = Course.objects.filter(id=course_id, instructor=self.request.user).first()
        if not course:
            raise PermissionError("You are not the instructor of this course.")
        serializer.save(course=course)


class CourseLessonsView(generics.ListAPIView):
    serializer_class = LessonSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        course_id = self.kwargs.get('pk')
        return Lesson.objects.filter(module__course_id=course_id).order_by('module__order', 'order')


class FeedbackCreateView(generics.CreateAPIView):
    serializer_class = FeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]


# =======================================
# 5) Course Detail (for frontend)
# =======================================

class CourseDetailView(generics.RetrieveAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.AllowAny]

    def retrieve(self, request, *args, **kwargs):
        course = self.get_object()
        lessons = Lesson.objects.filter(module__course=course)
        feedbacks = Feedback.objects.filter(course=course)

        course_data = CourseSerializer(course, context={'request': request}).data
        lessons_data = LessonSerializer(lessons, many=True, context={'request': request}).data
        feedbacks_data = FeedbackSerializer(feedbacks, many=True, context={'request': request}).data

        return Response({
            "course": course_data,
            "lessons": lessons_data,
            "reviews": feedbacks_data,
        })


# =======================================
# 6) Public & Instructor Utilities
# =======================================

class CourseSearchView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description', 'instructor__username']
    ordering_fields = ['price', 'created_at']
    ordering = ['-created_at']


class InstructorListView(generics.ListAPIView):
    queryset = User.objects.filter(role='instructor', is_approved=True)
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]

class InstructorEnrollmentListView(generics.ListAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsInstructor]

    def get_queryset(self):
        return Enrollment.objects.filter(course__instructor=self.request.user)

class InstructorCourseListView(generics.ListAPIView):
    serializer_class = CourseSerializer
    permission_classes = [IsInstructor]

    def get_queryset(self):
        return Course.objects.filter(instructor=self.request.user)


# =======================================
# ❌ Admin-related API views removed
# =======================================
# Removed:
# - ApproveInstructorView
# - AdminDashboardView
# - AdminInstructorListView
# - AdminRejectInstructorView
# - AdminAssignInstructorView
# - CertificateCreateView
# - OfferListCreateView
# - LiveSessionCreateView (admin-only)
# - DailyTaskCreateView (admin-only)
# Django superuser will handle those in the admin panel.
