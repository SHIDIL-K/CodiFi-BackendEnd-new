import React, { useContext, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";  
import AdminDashboard from "./pages/AdminDashboard";
import InstructorDashboard from "./pages/InstructorDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import AddCourse from "./pages/AddCourse";
import Profile from "./pages/ProfilePage"; // ✅ import Profile page
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ProtectedRoute from "./components/ProtectedRoute"; // ✅ import protected route
import { AuthContext } from "./context/AuthContext";
import Home from "./pages/Home";

function App() {
  const { loadUser } = useContext(AuthContext);

  useEffect(() => {
    loadUser(); // populate user on app load
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="container mx-auto px-4 py-6">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home/>} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/courses" element={<Courses />} />

          {/* ✅ Protected profile route (all logged-in users) */}
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route path="/courses/:id" 
          element={
            <ProtectedRoute>
              <CourseDetail />
            </ProtectedRoute>
              } />


          {/* ✅ Role-based protected routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute roleRequired="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/instructor"
            element={
              <ProtectedRoute roleRequired="instructor">
                <InstructorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/student"
            element={
              <ProtectedRoute roleRequired="student">
                <StudentDashboard />
              </ProtectedRoute>
            }
          />

          {/* ✅ Admin-only course creation */}
          <Route
            path="/admin/add-course"
            element={
              <ProtectedRoute roleRequired="admin">
                <AddCourse />
              </ProtectedRoute>
            }
          />

          {/* fallback */}
          <Route path="*" element={<div>404 Not Found</div>} />
        </Routes>
      </main>
      <Footer />
    </div>
    
  );
}

export default App;
