// src/components/Navbar.jsx
import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { UserCircle } from "lucide-react";
import ProtectedRoute from "../components/ProtectedRoute"; // ✅ import protected route


export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleProfileClick = () => {
    navigate("/profile");
  };

  return (
    <nav className="bg-gray-900 text-white px-6 py-3 flex justify-between items-center">
      <Link to="/courses" className="font-bold text-xl text-blue-600">CodiFi</Link>
      <Link to="/courses" className="text-sm text-white">Courses</Link>
      <ProtectedRoute roleRequired="student">
        <Link to="/student" className="text-sm text-white">Dashboard</Link>
      </ProtectedRoute>
      <ProtectedRoute roleRequired="instructor">
        <Link to="/instructor" className="text-sm text-white">Dashboard</Link>
      </ProtectedRoute>
      <div className="flex items-center space-x-4">
        {!user ? (
          <>
            <Link to="/login" className="px-3 py-1 mr-2 text-sm bg-blue-500 text-white rounded">Login</Link>
            <Link to="/signup" className="px-3 py-1 text-sm border rounded">Signup</Link>
          </>
        ) : (
          <>
            <button
              onClick={logout}
              className="px-3 py-1 bg-red-600 rounded hover:bg-red-700"
            >
              Logout
            </button>
            <div
              onClick={handleProfileClick}
              className="cursor-pointer w-10 h-10 rounded-full overflow-hidden border-2 border-white"
            >
              {user.profile_picture ? (
                <img
                  src={user.profile_picture}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="bg-gray-700 flex justify-center items-center w-full h-full">
                  <UserCircle className="w-6 h-6 text-gray-300" />
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </nav>
  );
}
