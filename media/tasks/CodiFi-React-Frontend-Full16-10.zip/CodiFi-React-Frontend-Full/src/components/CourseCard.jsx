import React from 'react'
import { Link } from 'react-router-dom'

export default function CourseCard({courses}){
  return (
    <div className="border rounded-md overflow-hidden shadow-sm hover:shadow-md transition p-3 bg-white">
      {courses.image && <img src={courses.image} alt={courses.title} className="w-full h-40 object-cover mb-3" />}
      <h3 className="font-semibold text-lg">{courses.title}</h3>
      <p className="text-sm text-gray-600">{courses.instructor_name || 'Instructor'}</p>
      <p className="mt-2 text-sm line-clamp-3">{courses.description}</p>
      <Button className='primary'>View</Button>
      <div className="flex items-center justify-between mt-3">
        <div className="text-lg font-bold">₹{courses.price}</div>
        <Link to={`/courses/${courses.id}`} className="px-3 py-1 bg-blue-600 text-white rounded">View</Link>
      </div>
    </div>
  )
}
