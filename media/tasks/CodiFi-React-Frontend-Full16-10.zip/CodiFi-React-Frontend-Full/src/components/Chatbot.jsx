import React from 'react'

export default function Chatbot(){
  return (
    <div className="fixed right-6 bottom-6">
      <button className="bg-blue-600 text-white p-3 rounded-full shadow-lg">💬</button>
    </div>
  )
}
