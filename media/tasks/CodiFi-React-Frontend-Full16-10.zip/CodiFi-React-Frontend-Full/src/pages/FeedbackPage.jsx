import React, {useState} from 'react'
import { fetchAPI } from "../api/fetchAPI";

export default function FeedbackPage(){
  const [form, setForm] = useState({course:'', rating:5, comment:''})

  const submit = async (e) =>{
    e.preventDefault()
    try{
      await fetchAPI('/feedbacks/', form)
      alert('Feedback submitted')
    }catch(err){ console.error(err) }
  }

  return (
    <div className="max-w-lg bg-white p-6 rounded shadow">
      <h2 className="text-2xl mb-4">Give Feedback</h2>
      <form onSubmit={submit} className="space-y-3">
        <input className="w-full border p-2 rounded" placeholder="course id" value={form.course} onChange={e=>setForm({...form, course:e.target.value})} />
        <input type="number" className="w-full border p-2 rounded" placeholder="rating" value={form.rating} onChange={e=>setForm({...form, rating:e.target.value})} />
        <textarea className="w-full border p-2 rounded" placeholder="comment" value={form.comment} onChange={e=>setForm({...form, comment:e.target.value})} />
        <button className="w-full bg-blue-600 text-white p-2 rounded">Submit</button>
      </form>
    </div>
  )
}
