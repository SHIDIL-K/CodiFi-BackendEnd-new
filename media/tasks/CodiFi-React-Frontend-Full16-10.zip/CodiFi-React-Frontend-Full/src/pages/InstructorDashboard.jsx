import React, { useContext, useEffect } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function InstructorDashboard() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/login");
    } else if (user.role !== "instructor") {
      // redirect to their role home
      if (user.role === "admin") navigate("/admin");
      else navigate("/student");
    }
  }, [user]);

  if (!user) return null;
  if (!user.is_approved) {
    return (
      <div className="bg-white p-6 rounded shadow">
        <h2 className="text-xl">Instructor account pending approval</h2>
        <p className="text-gray-600">Your instructor account is not yet approved by admin. Please wait for approval.</p>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Instructor Dashboard</h1>
      <div className="bg-white p-4 rounded shadow">
        <p>Welcome, {user.username}. Create lessons, tasks and manage your courses here (coming soon).</p>
      </div>
    </div>
  );
}
