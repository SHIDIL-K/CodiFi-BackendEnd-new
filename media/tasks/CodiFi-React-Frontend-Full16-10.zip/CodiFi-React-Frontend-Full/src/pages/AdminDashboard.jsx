import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";

const BASE_URL = "http://localhost:8000";

export default function AdminDashboard() {
  const { user, tokens } = useContext(AuthContext);
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (!user || user.role !== "admin") {
      navigate("/login");
      return;
    }

    (async () => {
      try {
        const res = await fetch(`${BASE_URL}/api/admin/dashboard/`, {
          headers: { Authorization: `Bearer ${tokens?.access}` }
        });
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch (err) {
        console.error(err);
      }
    })();
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Total Students</h3>
          <p className="text-xl font-semibold">{stats?.total_students ?? "—"}</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Total Instructors</h3>
          <p className="text-xl font-semibold">{stats?.total_instructors ?? "—"}</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Total Revenue</h3>
          <p className="text-xl font-semibold">₹{stats?.total_revenue ?? "—"}</p>
        </div>
      </div>

      <div className="mt-6">
        <Link to="/admin/add-course" className="px-4 py-2 bg-green-600 text-white rounded">Add Course</Link>
      </div>
    </div>
  );
}
