import React, {useEffect, useState} from 'react'
import { fetchAPI } from "../api/fetchAPI";

export default function TaskList(){
  const [tasks, setTasks] = useState([])

  useEffect(()=>{
    fetchAPI('/tasks/')
      .then(res=> setTasks(res.data))
      .catch(err=> console.error(err))
  },[])

  return (
    <div>
      <h2 className="text-2xl mb-4">Daily Tasks</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {tasks.map(t => (
          <div key={t.id} className="p-4 bg-white rounded shadow">
            <div className="font-semibold">{t.title}</div>
            <div className="text-sm text-gray-600">Course: {t.course.title}</div>
            <a href={`/tasks/${t.id}`} className="text-blue-600 text-sm">Submit</a>
          </div>
        ))}
      </div>
    </div>
  )
}
