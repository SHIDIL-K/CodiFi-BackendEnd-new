import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";

const BASE_URL = "http://localhost:8000";

export default function Profile() {
  const { user, tokens, refreshAccessToken, logout } = useContext(AuthContext);
  const [profile, setProfile] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [form, setForm] = useState({
    bio: "",
    phone: "",
    qualification: "",
    profile_picture: null,
  });

  useEffect(() => {
    const fetchProfile = async () => {
      if (!tokens?.access) return;
      const res = await fetch(`${BASE_URL}/api/profile/`, {
        headers: { Authorization: `Bearer ${tokens.access}` },
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
        setForm({
          bio: data.bio || "",
          phone: data.phone || "",
          qualification: data.qualification || "",
          profile_picture: null,
        });
      } else if (res.status === 401) {
        const newAccess = await refreshAccessToken();
        if (newAccess) return fetchProfile();
        logout();
      }
      setLoading(false);
    };
    fetchProfile();
  }, [tokens]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setForm({ ...form, profile_picture: e.target.files[0] });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setUpdating(true);

    const formData = new FormData();
    formData.append("bio", form.bio);
    formData.append("phone", form.phone);
    formData.append("qualification", form.qualification);
    if (form.profile_picture) formData.append("profile_picture", form.profile_picture);

    const res = await fetch(`${BASE_URL}/api/profile/`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${tokens.access}` },
      body: formData,
    });

    if (res.ok) {
      const data = await res.json();
      setProfile(data);
      setEditMode(false);
    } else {
      alert("Failed to update profile");
    }

    setUpdating(false);
  };

  if (loading) return <p className="text-center">Loading profile...</p>;
  if (!profile) return <p className="text-center text-red-500">Failed to load profile.</p>;

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded shadow">
      {!editMode ? (
        <>
          <div className="flex items-center space-x-4 mb-4">
            {profile.profile_picture ? (
              <img
                src={profile.profile_picture}
                alt="Profile"
                className="w-20 h-20 rounded-full object-cover"
              />
            ) : (
              <div className="w-20 h-20 bg-gray-300 rounded-full flex items-center justify-center text-gray-700">
                No Photo
              </div>
            )}
            <div>
              <h2 className="text-2xl font-bold">
                {profile.username} ({profile.role})
              </h2>
              <p className="text-gray-600">{profile.email}</p>
            </div>
          </div>

          <p><strong>Bio:</strong> {profile.bio || "N/A"}</p>
          <p><strong>Phone:</strong> {profile.phone || "N/A"}</p>
          {profile.role === "instructor" && (
            <p><strong>Qualification:</strong> {profile.qualification || "N/A"}</p>
          )}

          <button
            onClick={() => setEditMode(true)}
            className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
          >
            Edit Profile
          </button>
        </>
      ) : (
        <form onSubmit={handleUpdate} className="space-y-3">
          <label className="block text-sm font-medium">Bio</label>
          <textarea
            name="bio"
            value={form.bio}
            onChange={handleChange}
            className="w-full border p-2 rounded"
          />

          <label className="block text-sm font-medium">Phone</label>
          <input
            name="phone"
            value={form.phone}
            onChange={handleChange}
            className="w-full border p-2 rounded"
          />

          {profile.role === "instructor" && (
            <>
              <label className="block text-sm font-medium">Qualification</label>
              <input
                name="qualification"
                value={form.qualification}
                onChange={handleChange}
                className="w-full border p-2 rounded"
              />
            </>
          )}

          <label className="block text-sm font-medium">Profile Picture</label>
          <input type="file" accept="image/*" onChange={handleFileChange} />

          <div className="flex space-x-3 mt-4">
            <button
              type="submit"
              disabled={updating}
              className="bg-green-600 text-white px-4 py-2 rounded"
            >
              {updating ? "Saving..." : "Save"}
            </button>
            <button
              type="button"
              onClick={() => setEditMode(false)}
              className="bg-gray-400 text-white px-4 py-2 rounded"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
