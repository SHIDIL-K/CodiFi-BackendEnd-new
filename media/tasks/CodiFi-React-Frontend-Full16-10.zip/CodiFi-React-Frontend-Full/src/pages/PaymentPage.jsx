import React, {useEffect, useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { fetchAPI } from "../api/fetchAPI";

export default function PaymentPage(){
  const { courseId } = useParams()
  const [course, setCourse] = useState(null)
  const navigate = useNavigate()

  useEffect(()=>{
    fetchAPI(`/courses/${courseId}/`)
      .then(res=> setCourse(res.data))
      .catch(err=> console.error(err))
  },[courseId])

  const payNow = async () => {
    // Mock payment: create Payment record on backend. Replace with Razorpay/Stripe integration.
    try{
      await fetchAPI('/payments/', { course: courseId, amount: course.price, transaction_id: `TXN${Date.now()}`, status: 'success' })
      navigate('/student')
    }catch(err){
      console.error(err)
    }
  }

  if(!course) return <div>Loading...</div>

  return (
    <div className="max-w-lg mx-auto bg-white p-6 rounded shadow">
      <h3 className="text-xl font-semibold">Payment for {course.title}</h3>
      <p className="mt-2">Amount: ₹{course.price}</p>
      <button onClick={payNow} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">Pay (Mock)</button>
    </div>
  )
}
