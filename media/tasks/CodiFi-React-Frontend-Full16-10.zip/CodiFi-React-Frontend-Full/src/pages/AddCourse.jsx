import React, { useState, useContext, useEffect } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const BASE_URL = "http://localhost:8000";

export default function AddCourse() {
  const { user, tokens } = useContext(AuthContext);
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState(null);
  const [instructorId, setInstructorId] = useState("");
  const [instructors, setInstructors] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // prevent non-admin from seeing this page
    if (!user || user.role !== "admin") {
      navigate("/login");
      return;
    }

    // load approved instructors to optionally assign
    (async () => {
      try {
        const res = await fetch(`${BASE_URL}/api/users/`); // NOTE: you may need to add an endpoint to list users or instructors in backend
        if (res.ok) {
          const data = await res.json();
          setInstructors(data.filter(u => u.role === 'instructor' && u.is_approved));
        } else {
          // fallback: do nothing
        }
      } catch (err) {
        console.warn("Could not load instructors list (backend endpoint missing)", err);
      }
    })();
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("title", title);
      fd.append("description", description);
      fd.append("price", price);
      if (image) fd.append("image", image);
      if (instructorId) fd.append("instructor", instructorId);

      const res = await fetch(`${BASE_URL}/api/admin/create-course/`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${tokens?.access}`
        },
        body: fd
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
      alert("Course created");
      navigate("/courses");
    } catch (err) {
      setError(err.message || "Failed to create course");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl mb-4">Add Course (Admin)</h2>
      {error && <div className="mb-4 text-red-600">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-3">
        <input required value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" className="w-full border p-2 rounded" />
        <textarea required value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" className="w-full border p-2 rounded" />
        <input required value={price} type="number" onChange={e => setPrice(e.target.value)} placeholder="Price" className="w-full border p-2 rounded" />
        <input type="file" accept="image/*" onChange={e => setImage(e.target.files[0])} />
        <select value={instructorId} onChange={e => setInstructorId(e.target.value)} className="w-full border p-2 rounded">
          <option value="">— Assign Instructor (optional) —</option>
          {instructors.map(i => <option key={i.id} value={i.id}>{i.username}</option>)}
        </select>

        <button disabled={loading} type="submit" className="w-full bg-green-600 text-white py-2 rounded">
          {loading ? "Creating..." : "Create Course"}
        </button>
      </form>
    </div>
  );
}
