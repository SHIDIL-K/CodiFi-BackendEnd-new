import React, {useEffect, useState, useContext} from 'react'
import { AuthContext } from "../context/AuthContext";

import { useParams, useNavigate } from 'react-router-dom'

const BASE_URL = "http://localhost:8000";


export default function CourseDetail(){
  const [courses, setCourses] = useState([]);
    const [loading, setLoading] = useState(true);
    const { user } = useContext(AuthContext);
  
    useEffect(() => {
      const load = async () => {
        setLoading(true);
        try {
          const res = await fetch(`${BASE_URL}/api/courses/`); // your endpoint
          const data = await res.json();
          setCourses(data);
        } catch (err) {
          console.error(err);
        } finally {
          setLoading(false);
        }
      };
      load();
    }, []);
  

  // if(!course) return <div>Loading...</div>

  return (
    <div>
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Courses</h1>
            {user?.role === "admin" && (
              <Link to="/admin/add-course" className="px-4 py-2 bg-green-600 text-white rounded">Add Course</Link>
            )}
          </div>
    
          {loading ? (
            <div>Loading...</div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {courses.map((c) => (
                <div key={c.id} className="bg-white p-4 rounded shadow">
                  <h3 className="text-lg font-semibold">{c.title}</h3>
                  {courses.image && <img src={c.image} alt={c.title} className="w-full h-40 object-cover mb-3" />}
                  <p className="text-sm text-gray-600">{c.description?.slice(0, 120)}...</p>
                  <p className="mt-2 font-bold">₹{c.price}</p>
                  <p className="text-xs text-gray-500 mt-2">Instructor: {c.instructor_name || "TBA"}</p>
                  {/* <Link to="/courses/:id" className="px-3 py-1 mr-2 text-sm bg-blue-500 text-white rounded">View</Link> */}
                  
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }
    