import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const BASE_URL = "http://localhost:8000";

export default function Signup() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student"); // 'student' | 'instructor' | 'admin'
  const [certificate, setCertificate] = useState(null);
  const [experience, setExperience] = useState("");
  const [qualification, setQualification] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      let endpoint = `${BASE_URL}/api/register/`;
      if (role === "student") endpoint = `${BASE_URL}/api/register/student/`;
      if (role === "instructor") endpoint = `${BASE_URL}/api/register/instructor/`;
      // if (role === "admin") endpoint = `${BASE_URL}/api/register/admin/`; // typically protected by backend

      // If instructor and we have a certificate file, send multipart/form-data
      if (role === "instructor") {
        const formData = new FormData();
        formData.append("username", username);
        formData.append("email", email);
        formData.append("password", password);
        formData.append("role", "instructor");
        if (certificate) formData.append("certificate", certificate);
        formData.append("experience", experience);
        formData.append("qualification", qualification);

        const res = await fetch(endpoint, {
          method: "POST",
          body: formData,
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
      } else {
        // JSON body
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, email, password, role }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
      }

      alert("Signup successful! Please login. (If you registered as instructor, wait for admin approval.)");
      navigate("/login");
    } catch (err) {
      setError(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl mb-4">Signup</h2>
      {error && <div className="mb-4 text-red-600">{error}</div>}

      <form onSubmit={handleSignup} className="space-y-3">
        <input required value={username} onChange={e => setUsername(e.target.value)} placeholder="Username" className="w-full border p-2 rounded" />
        <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" className="w-full border p-2 rounded" />
        <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" className="w-full border p-2 rounded" />

        <label className="block text-sm">Register as</label>
        <select value={role} onChange={e => setRole(e.target.value)} className="w-full border p-2 rounded">
          <option value="student">Student</option>
          <option value="instructor">Instructor</option>
          {/* <option value="admin">Admin (only create via admin panel in prod)</option> */}
        </select>

        {role === "instructor" && (
          <>
            <label className="block text-sm">Certificate (PDF)</label>
            <input type="file" accept=".pdf,.jpg,.png" onChange={(e) => setCertificate(e.target.files[0])} />
            <input value={experience} onChange={e => setExperience(e.target.value)} placeholder="Experience (e.g., 3 years)" className="w-full border p-2 rounded" />
            <input value={qualification} onChange={e => setQualification(e.target.value)} placeholder="Qualification" className="w-full border p-2 rounded" />
            <p className="text-xs text-gray-500">Instructors require admin approval before login.</p>
          </>
        )}

        <button disabled={loading} type="submit" className="w-full bg-blue-600 text-white py-2 rounded">
          {loading ? "Signing up..." : "Signup"}
        </button>
      </form>
    </div>
  );
}
