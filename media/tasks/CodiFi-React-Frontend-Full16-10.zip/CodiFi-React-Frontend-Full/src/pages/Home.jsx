import React, {useEffect, useState} from 'react'
import CourseCard from '../components/CourseCard'

export default function Home(){
  // const [courses, setCourses] = useState([])

  // useEffect(()=>{
  //   fetchAPI('/courses/')
  //     .then(res=> setCourses(res.data))
  //     .catch(err=> console.error(err))
  // },[])

  return (
    <div>
      <section className="bg-gradient-to-r from-sky-50 to-white py-12 rounded mb-8">
        <div className="container-wide px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl font-bold mb-4">Learn in-demand Computer Science skills</h1>
            <p className="text-gray-700 mb-4">Join courses, complete daily tasks, and earn certificates. Powered by instructors and smart analytics.</p>
            <a href="/courses" className="px-5 py-3 bg-blue-600 text-white rounded">Browse Courses</a>
          </div>
          <div>
            <img alt="hero" src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80" className="rounded shadow" />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Popular Courses</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {courses.map(c => <CourseCard key={c.id} course={c} />)}
        </div>
      </section>
    </div>
  )
}
